#!/bin/sh
#
# author: Damiano Varagnolo
# date:   February 22 2010
#
# remember to run 'chmod +x'


# name of the backup file
echo "Enter the name of the backup file (without the extension)"
read N

mkdir ../tmp_folder_to_delete/
cp -r * ../tmp_folder_to_delete/
cp /home/damiano/Backups/ShellScripts/RemoveVersioningAndBackupFiles.sh ../tmp_folder_to_delete/
cd ../tmp_folder_to_delete/
chmod +x RemoveVersioningAndBackupFiles.sh
./RemoveVersioningAndBackupFiles.sh
7z a -tzip $N -r *
cp $N.zip /home/damiano/Backups
cd ..
rm -rf tmp_folder_to_delete

