function StartStopwatch( tTimeToCompletionForecaster )
	%
	tic;
	%
	tTimeToCompletionForecaster.fStartingTime = toc;
	%
end %
