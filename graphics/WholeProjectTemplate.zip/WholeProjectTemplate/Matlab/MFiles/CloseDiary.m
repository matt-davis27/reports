if( tParameters.bActivateDiaryFile )
	%
	diary off;
	%
end;%
