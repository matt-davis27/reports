#!/bin/sh
#
# author: Damiano Varagnolo
# date:   February 22 2010
#
# remember to run 'chmod +x'

./Scripts/impressive.py --transition=none ./Sources/main.pdf

