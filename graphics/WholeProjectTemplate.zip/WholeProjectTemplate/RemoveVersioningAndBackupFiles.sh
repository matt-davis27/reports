#!/bin/sh
#
# author: Damiano Varagnolo
# date:   February 21 2010
#
# remember to run 'chmod +x'


# temporary files
find . -name *.m~       -exec /bin/rm -f '{}' \;
find . -name *.tex~     -exec /bin/rm -f '{}' \;
find . -name *.bib~     -exec /bin/rm -f '{}' \;
find . -name *.txt~     -exec /bin/rm -f '{}' \;
find . -name *.sh~      -exec /bin/rm -f '{}' \;
#
find . -name *.backup   -exec /bin/rm -f '{}' \;
find . -name *.log      -exec /bin/rm -f '{}' \;
find . -name *.tps      -exec /bin/rm -f '{}' \;
find . -name *.aux      -exec /bin/rm -f '{}' \;
find . -name *.blg      -exec /bin/rm -f '{}' \;
find . -name *.out      -exec /bin/rm -f '{}' \;
find . -name *.bbl      -exec /bin/rm -f '{}' \;
find . -name *.brf      -exec /bin/rm -f '{}' \;
find . -name *.lot      -exec /bin/rm -f '{}' \;
find . -name *.toc      -exec /bin/rm -f '{}' \;

# svn files
find . -name *.svn-base  -exec /bin/rm -f '{}' \;
find . -name all-wcprops -exec /bin/rm -f '{}' \;
find . -name entries     -exec /bin/rm -f '{}' \;
find . -name format      -exec /bin/rm -f '{}' \;

# svn directories
find . -name prop-base -exec /bin/rmdir '{}' \;
find . -name text-base -exec /bin/rmdir '{}' \;
find . -name props     -exec /bin/rmdir '{}' \;
find . -name tmp       -exec /bin/rmdir '{}' \;
find . -name .svn      -exec /bin/rmdir '{}' \;
